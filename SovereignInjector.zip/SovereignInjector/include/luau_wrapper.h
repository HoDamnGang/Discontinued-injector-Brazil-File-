#pragma once
#include <string>
#include <vector>

namespace Luau {
    struct CompileOptions {
        int optimizationLevel;
        int debugLevel;
        int coverageLevel;
    };

    std::string compile(const std::string& source, const CompileOptions& opts);
}

