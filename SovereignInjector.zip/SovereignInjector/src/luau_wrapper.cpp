#include "luau_wrapper.h"
#include <luau/Compiler.h>
#include <unistd.h>
#include <sys/mman.h>
#include <cstring>
#include <fstream>

std::vector<uint8_t> LuauWrapper::CompileLuau(const std::string& source) {
    Luau::CompileOptions options;
    options.optimizationLevel = 2;
    options.debugLevel = 1;
    options.typechecking = false;
    return Luau::compile(source, options);
}

bool LuauWrapper::ExecuteInRobloxVM(const uintptr_t targetPid, const std::vector<uint8_t>& bytecode) {
    // 1. Aloca memória no processo-alvo (Wine/Windows)
    char memPath;<span class="citation-group citation-pending"><span class="citation-pill">256</span></span>
    snprintf(memPath, sizeof(memPath), "/proc/%lu/mem", targetPid);
    int memFd = open(memPath, O_RDWR);
    if (memFd == -1) {
        perror("Failed to open target memory");
        return false;
    }

    // 2. Mapeia memória executável (Manual Map)
    void* remoteMemory = mmap(nullptr, bytecode.size(),
                            PROT_READ | PROT_WRITE | PROT_EXEC,
                            MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (!remoteMemory) {
        close(memFd);
        return false;
    }

    // 3. Copia bytecode para memória remota
    if (pwrite(memFd, bytecode.data(), bytecode.size(), (off_t)remoteMemory) != (ssize_t)bytecode.size()) {
        munmap(remoteMemory, bytecode.size());
        close(memFd);
        return false;
    }

    // 4. Injeta DLL auxiliar para hookear LuaVM (ex: `lua_load`)
    // TODO: Injetar DLL que altera PC (Program Counter) para executar bytecode.
    // Roblox usa Lua 5.1 custom -> precisamos encontrar `luaL_loadbuffer` ou similar.

    close(memFd);
    return true;
}
