#include <iostream>
#include <fstream>
#include "luau_wrapper.h"
#include "wine_bridge.h"

int main(int argc, char** argv) {
    if (argc < 2) {
        std::cerr << "Uso: ./SovereignInjector <script.luau>" << std::endl;
        return 1;
    }

    // 1. Compila script Luau
    std::ifstream scriptFile(argv<span class="citation-group citation-pending"><span class="citation-pill">1</span></span>);
    std::string source((std::istreambuf_iterator<char>(scriptFile)),
                     std::istreambuf_iterator<char>());
    scriptFile.close();

    auto bytecode = LuauWrapper::CompileLuau(source);
    if (bytecode.empty()) {
        std::cerr << "Falha na compilação do Luau." << std::endl;
        return 1;
    }

    // 2. Encontra processo do Roblox
    uintptr_t robloxPid = WineBridge::FindRobloxProcess();
    if (!robloxPid) {
        std::cerr << "Roblox não está rodando no Sober." << std::endl;
        return 1;
    }
    std::cout << "[+] Roblox PID: " << robloxPid << std::endl;

    // 3. Injeta bytecode LuaVM
    if (!LuauWrapper::ExecuteInRobloxVM(robloxPid, bytecode)) {
        std::cerr << "Falha na injeção." << std::endl;
---

### **3.4 Executor Completo: [`main.cpp`]**
> Inicia a injeção no processo do Roblox (via Sober/Wine), carrega o script Luau compilado, e executa com sandbox manual.

```cpp
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <unistd.h>
#include <sys/wait.h>
#include "injector.h"
#include "bypass.h"
#include "luau_wrapper.h"

int main(int argc, char* argv[]) {
    if (argc < 4) {
        std::cerr << R"(
[!] Uso:
      ./SovereignInjector <process_name> <script.luau> [--sandbox]

[!] Exemplos:
      ./SovereignInjector RobloxPlayerBeta.exe hello.luau
      ./SovereignInjector RobloxPlayerBeta.exe atualizar_ui.luau --sandbox
)" << std::endl;
        return 1;
    }

    const char* processName = argv;<span class="citation-group citation-pending"><span class="citation-pill">1</span></span>
    const char* scriptPath = argv;<span class="citation-group citation-pending"><span class="citation-pill">2</span></span>
    bool useSandbox = (argc > 3 && std::string(argv<span class="citation-group citation-pending"><span class="citation-pill">3</span></span>) == "--sandbox");

    // 1. Localiza PID do processo via /proc
    uintptr_t targetPid = 0;
    std::string pidCmd = "pgrep -f " + std::string(processName);
    FILE* pidPipe = popen(pidCmd.c_str(), "r");
    if (!pidPipe) {
        std::cerr << "[-] Falha ao abrir pipe do PID" << std::endl;
        return 1;
    }
    char buffer;<span class="citation-group citation-pending"><span class="citation-pill">32</span></span>
    if (fgets(buffer, sizeof(buffer), pidPipe)) {
        targetPid = std::stoul(buffer);
    } else {
        std::cerr << "[-] Processo " << processName << " não encontrado no Sober." << std::endl;
        pclose(pidPipe);
        return 1;
    }
    pclose(pidPipe);

    std::cout << "[+] Processo " << processName << " encontrado no PID: " << targetPid << std::endl;

    // 2. Bypass anti-cheat (Oculta DLLs, desativa AMSI, etc.)
    std::cout << "[+] Aplicando bypass anti-detection..." << std::endl;
    AntiDetection::PatchAMSI();
    AntiDetection::PatchETW();
    AntiDetection::BlockDynamicScan(targetPid);

    // 3. Carrega script .luau em bytecode
    std::ifstream scriptFile(scriptPath, std::ios::binary);
    if (!scriptFile) {
        std::cerr << "[-] Script " << scriptPath << " não encontrado." << std::endl;
        return 1;
    }

    std::string luauScript((std::istreambuf_iterator<char>(scriptFile)),
                            std::istreambuf_iterator<char>());
    scriptFile.close();

    std::string bytecode = Luau::compile(luauScript, {1, 1, nullptr, 0}); // Otimizado

    // 4. Injeta o bytecode na memória do Roblox via Memory Mapping
    ProcessInjector injector(targetPid);
    if (!injector.ManualMap(std::vector<uint8_t>(bytecode.begin(), bytecode.end()))) {
        std::cerr << "[-] Falha na injeção de bytecode." << std::endl;
        return 1;
    }

    std::cout << "[+] Bytecode Lua injetado no PID " << targetPid << std::endl;

    // 5. Aciona execução via Remote Call (Hook na Lua VM)
    if (!useSandbox) {
        std::cout << "[!] Sandbox desabilitado. ATENÇÃO: Pode ser detectado pelo Byfron/AP." << std::endl;
    } else {
        std::cout << "[+] Sandbox ativado (restringe os Libs permitidos)." << std::endl;
    }

    // TODO: Implementar hooking da LuaVM para acionar o script no Roblox.
    // Isso envolve: encontrar o endereço da Lua VM dentro do Roblox e chamar uma função como `luaL_dostring`.

    // --- Waiting for crash or successful execution ---
    std::cout << "[!] Aguardando execução... (Ctrl+C para sair)" << std::endl;
    while (true) {
        usleep(500000); // 0.5s
        // Você pode checar status/retorno do script aqui.
    }

    return 0;
}
