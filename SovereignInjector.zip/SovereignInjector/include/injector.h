#pragma once
#include <cstdint>
#include <string>

class ProcessInjector {
public:
    ProcessInjector(const uintptr_t pid);
    ~ProcessInjector();

    bool InjectDLL(const std::string& dllPath);
    bool ManualMap(const std::vector<uint8_t>& bytecode);

    uintptr_t GetTargetPid() const { return targetPid; }

private:
    uintptr_t targetPid;
    void* remoteThread;
    void* remoteMemory;
};
