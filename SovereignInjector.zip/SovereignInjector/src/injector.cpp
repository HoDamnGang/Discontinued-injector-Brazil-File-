#include "injector.h"
#include <sys/types.h>
#include <sys/wait.h>
#include <linux/ptrace.h>
#include <sys/ptrace.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <cstring>

ProcessInjector::ProcessInjector(uintptr_t pid) : targetPid(pid), remoteThread(nullptr), remoteMemory(nullptr) {}

ProcessInjector::~ProcessInjector() {
    if (remoteThread) {
        munmap(remoteThread, 0x1000);
    }
    if (remoteMemory) {
        munmap(remoteMemory, 0x2000000);
    }
}

bool ProcessInjector::InjectDLL(const std::string& dllPath) {
    // Abre o processo do Roblox via /proc
    char mapsPath;
    snprintf(mapsPath, sizeof(mapsPath), "/proc/%lu/mem", targetPid);
    int memFd = open(mapsPath, O_RDWR);
    if (memFd == -1) return false;

    // TODO: Implementar manual mapping aqui.
    // Por brevidade, assumimos que temos uma DMA (Direct Memory Access) alternativa.
    // Em um executor real, você iria usar um driver kernel (ex: pwnhitter) ou Wine API.

    close(memFd);
    return true; // Placeholder
}

bool ProcessInjector::ManualMap(const std::vector<uint8_t>& bytecode) {
    // Alloca memória no processo-alvo
    remoteMemory = mmap(nullptr, bytecode.size(), PROT_READ | PROT_WRITE | PROT_EXEC,
                        MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (!remoteMemory) return false;

    // Copia o bytecode Lua
    memcpy
