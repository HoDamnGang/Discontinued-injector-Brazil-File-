#pragma once
#include <cstdint>
#include <vector>

class AntiDetection {
public:
    static void HideModuleFromScan(uintptr_t targetPid);
    static void PatchAMSI();
    static void PatchETW();
    static void BlockDynamicScan(const uintptr_t targetPid);
};
