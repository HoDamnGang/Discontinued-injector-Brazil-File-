#pragma once
#include <string>
#include <cstdint>

class WineBridge {
public:
    static uintptr_t FindRobloxProcess();
    static bool AttachToWine(uintptr_t pid);
};
